import pandas as pd
# First upload the CSV file in the pycharm using pd.read_csv function
netflix = pd.read_csv("C:/Users/anura/Downloads/archive (1)/netflix_titles.csv")
print(netflix.info())
# check the data has been uploded or not using print
print(netflix.head(10))

#  Now we have to check what colums are there in this table
print(netflix.info())

# Removing unnecessay colums such as cast,description and directors
netflix.drop(columns = ['cast','description','director'],inplace=True)

# checking the columns are removed or not
print(netflix.info())

# checking are there any null values
print(netflix.isnull().sum())

#to deal with null values in country column
most_common_country = netflix['country'].value_counts().idxmax()
print(most_common_country)

# Filling the null columns in country with most common country name
netflix['country'].fillna('United States',inplace = True)
print(netflix['country'].value_counts())

# Using ffill function for values like date_added,rating and duration
netflix['date_added'].fillna(method='ffill',inplace=True)
netflix['rating'].fillna(method='ffill',inplace=True)
netflix['duration'].fillna(method='ffill',inplace=True)

# Finding the duplicated values in the table
for col in netflix.columns:
    duplicate_count = netflix[col].duplicated().sum()
    if duplicate_count > 0:
        print(f"'{col}' has {duplicate_count} duplicate values.")
    else:
        print(f"'{col}' has no duplicate values.")

#  Converting the date and time formate
netflix['date_added'] = pd.to_datetime(netflix['date_added'], format='mixed')
netflix['release_year'] = pd.to_datetime(netflix['release_year']).dt.year

#  Removing any spaces between the data
netflix = netflix.applymap(lambda x: x.replace(' ', '') if isinstance(x, str) else x)
print(netflix.info())

# saving the file in the desktop after cleaning
file_path = "C:/Users/anura/OneDrive/Desktop/Cleaned_Netflix.csv"
netflix.to_csv(file_path, index=False)
print(f"File saved successfully at: {file_path}")